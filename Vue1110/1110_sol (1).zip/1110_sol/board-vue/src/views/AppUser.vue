<template>
  <div>
    <h2>Login Page입니다.</h2>
    <div>나중에 로그인 화면 만들거에요!!!</div>
  </div>
</template>

<script>
export default {
  name: "AppUser",
};
</script>

<style></style>
