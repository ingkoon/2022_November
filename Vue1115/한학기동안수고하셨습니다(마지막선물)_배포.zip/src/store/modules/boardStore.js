const boardStore = {
  namespaced: true,
  state: {},
  getters: {},
  mutations: {},
  actions: {},
};

export default boardStore;
